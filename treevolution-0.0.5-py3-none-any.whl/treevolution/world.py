"""
Module which contains World class
"""
import random
from datetime import timedelta

# treevolution imports
from .context.weather import Weather
from .context.context import Context
from .models.state import TreeState, SeedState

class World():
    """
    World class in order to represent the forest and simulate the evolution of trees
    """

    N_EVOLVED_TREEES = 10

    def __init__(self, start_date, width, height):
        """
        World constructor: initializes the world time and size

        Attributes:
            start_date: {date} -- date of beginning of the simulation
            width: {int} -- expected width of world
            height: {int} -- expected height of world
        """
        self._date = start_date
        self._width = width
        self._height = height
        self._trees = []
        self._seeds = []
        self._last_weather = Weather.random(start_date)

    def add_tree(self, tree):
        """
        Add tree into the current world representation

        Attributes:
            tree: {:class:`~treevolution.models.tree.Tree`} -- specific subclass instance of Tree
        """
        self._trees.append(tree)

    def add_seed(self, seed):
        """
        Add seed into the current world representation

        Attributes:
            seed: {:class:`~treevolution.models.seed`} -- specific subclass instance of Seed
        """
        self._seeds.append(seed)


    def step(self):
        # pylint: disable=line-too-long
        """
        Simulate a day inside the current world

        Returns:
            (date, {:class:`~treevolution.context.weather.Weather`}, [{:class:`~treevolution.models.tree.Tree`}], [{:class:`~treevolution.models.seed`}]): tuple with date and simulated elements
        """
        # pylint: enable=line-too-long
        self._date += timedelta(days=1)

        weather = Weather.random(self._date)

        for tree in self._trees:

            # first check trees to remove from list (humus end state)
            if tree.consumed:
                self._trees.remove(tree)

        # only get a certain number of trees to evolve
        current_size = World.N_EVOLVED_TREEES \
            if World.N_EVOLVED_TREEES <= len(self._trees) \
            else len(self._trees)
            
        selected_trees = random.sample(self._trees, k=current_size)

        for tree in selected_trees:
            self._simulate_tree(tree, weather)
        
        # continue to evolve the mature seed on world
        for seed in self._seeds:
            self._simulate_seed(seed, weather)
        
        # keep track of current weather
        self._last_weather = weather

        # return the context
        return (self._date, self._last_weather, self._trees, self._seeds)

    def _simulate_tree(self, tree, weather):
        """Simulate specific tree of the world

        Attributes:
            trees: {:class:`~treevolution.models.tree.Tree`} -- tree to simulate
            weather: {:class:`~treevolution.context.weather.Weather`} -- current day weather
        """

        # need to filter the perceived sun by current tree
        # => depending of branches of neighbor trees
        sun_intensity = weather.sun
        filtered_intensities = []
        humus = 0

        # filtered list of trees in order to avoid current tree
        trees_to_check = filter(lambda neighbor: neighbor is not tree, self._trees)
        for neighbor in trees_to_check:
                        
            if tree.coordinate.is_inside_circle(neighbor.coordinate, neighbor.radius):
                
                # get neighbor tree branch density
                max_branch_length = neighbor.radius

                for branch in neighbor.branches:
                    
                    # check branch height and broken state
                    if branch.height > tree.height and not branch.broken:

                        # decrease factor by branch length
                        branch_filter = branch.density * (branch.length / max_branch_length)
                        filtered_intensities.append(branch_filter)

                # humus enable static bonus
                if neighbor.state == TreeState.HUMUS:
                    humus += 1

        # substract the lost sun intensity
        # it's possible that tree do not receive any sun
        final_intensity = sun_intensity - sum(filtered_intensities)
        final_intensity = max(final_intensity, 0) # check negative
        
        # need to also add humus energy 
        tree_context = Context(weather, final_intensity, humus)

        tree.evolve(tree_context)


    def _simulate_seed(self, seed, weather):
        """Simulate specific seed of the world

        Attributes:
            seeds: {:class:`~treevolution.models.seed.Seed`} -- seed to simulate
            weather: {:class:`~treevolution.context.weather.Weather`} -- current day weather
        """

        seed.evolve(weather)

        # check if necessary to remove the poor seed
        if seed.state in [SeedState.DEAD, SeedState.EATEN]:

            self._seeds.remove(seed)

        # check if new tree appear
        elif seed.state == SeedState.TREE:
        
            new_tree = seed.tree_type(seed.coordinate, weather.day, self)

            self._trees.append(new_tree)
            # need to remove seed
            self._seeds.remove(seed)

    
    def state(self):
        # pylint: disable=line-too-long
        """
        Get the current state of World
        
        Returns:
            (date, {:class:`~treevolution.context.weather.Weather`}, [{:class:`~treevolution.models.tree.Tree`}], [{:class:`~treevolution.models.seed`}]): tuple with date and simulated elements
        """
        # pylint: enable=line-too-long
        return (self._date, self._last_weather, self._trees, self._seeds)

    @property
    def width(self):
        """
        Let access to the `width` property of World
        
        Returns: 
            {int}: the `width` World property
        """
        return self._width

    @property
    def height(self):
        """
        Let access to the `height` property of World
        
        Returns: 
            {int}: the `height` World property
        """
        return self._height

    @property
    def date(self):
        """
        Let access to the `date` property of World
        
        Returns: 
            {datetime}: the `date` World property
        """
        return self._date

    def to_json(self):
        """
        Convert current instance of world into json data
        
        Returns: 
            {json}: the json representation of the world
        """
        
        return {
            "current_date": str(self._date),
            "width": self._width,
            "height": self._height,
            "weather": self._last_weather.to_json(),
            "trees": [t.to_json() for t in self._trees],
            "seeds": [s.to_json() for s in self._seeds]
        }
