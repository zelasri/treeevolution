"""
treevolution.models.trees module imports
"""
from .oak import Oak, Ash
