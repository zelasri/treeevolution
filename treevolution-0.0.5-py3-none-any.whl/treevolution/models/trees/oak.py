"""
Module for Oak tree specific representation
"""
import random

# treevolution imports
from ..tree import Tree
from ..branches.oak import OakBranch
from ..state import TreeState

class Oak(Tree):
    """
    Specific Oak tree class
    """

    MIN_HEIGHT, MAX_HEIGHT = 5, 7
    MIN_AGE, MAX_AGE = 5, 10
    PERCENT_BEFORE_BRANCH = 0.2

    def __init__(self, coordinate, birth, world):
        """
        Specific constructor for OakBranch: inherits from Branch constructor

        Attributes:
            coordinate: {:class:`~treevolution.base.geometry.Point`} -- tree position on the world
            birth: {date} -- the date of birth of the tree
            wolrd: {:class:`~treevolution.world.World`} -- associated world
        """
        super().__init__(coordinate, birth, world)

        self._max_age = random.uniform(Oak.MIN_AGE, Oak.MAX_AGE)
        self._max_height = random.uniform(Oak.MIN_HEIGHT, Oak.MAX_HEIGHT)

    @property
    def health(self):
        """
        Compute the current health of the OakTree
        Available branches can affect the OakTree health

        Returns: 
            {float}: the current tree health
        """

        if self.state == TreeState.HUMUS:
            return 0
        
        if len(self._branches) > 0:
            available_branches = len([ b for b in self._branches if not b.broken ])
        
            return self._nutrient * (available_branches / len(self._branches))

        return self._nutrient

    @property
    def width(self):
        """
        Determine the width of the trunk tree based of its height and specie

        Returns:
            {float} -- the trunk width of tree
        """
        return self._height * 0.08

    def evolve(self, context):
        """
        Simulate oak tree behavior with current day context

        Attributes:
            context: {:class:`~treevolution.context.context.Context`} -- context of the day
        """
        super().evolve(context)

        # if state is HUMUS due to end of life
        if self.state == TreeState.HUMUS:
            return

        # by default
        self._nutrient -= 0.2
        
        # 1. increase nutrient capacity (multiply by humus resource)
        self._nutrient += context.weather.humidity
        self._nutrient += (context.weather.humidity * context.humus)
        
        self._nutrient = min(self._nutrient, 100)
        self._nutrient = max(self._nutrient, 0)

        # 2. check if branch can be created
        if context.energy > 0.2 and self.health > 50 and random.random() < 0.02:

            angle = random.random() * 360
            # use % of height instead to determine min height branch
            height = random.uniform(Oak.PERCENT_BEFORE_BRANCH * self._height, self._height)

            oak_branch = OakBranch(height, angle, context.weather.day, self)
            self.add_branch(oak_branch)

            self._nutrient -= 5
            
        # 3. increase height tree linearly
        if self._height < self._max_height:

            increased_height = (0.005 * self.youth_ratio)
            self._height += increased_height
            
            # need to set new height for each branch
            for branch in self._branches:
                branch.height = branch.height + increased_height

        # 4. check if tree can fall depending of health and wind
        if context.weather.wind_speed > 140 and self.health < 10 \
            and not self.fallen and random.random() < 0.2:
            
            self.fallen = True
            
class Ash(Oak):
    """
    Copy of oak class for testing purpose
    """
    
    MIN_HEIGHT, MAX_HEIGHT = 10, 15
    MIN_AGE, MAX_AGE = 12, 14
    PERCENT_BEFORE_BRANCH = 0.15

    def __init__(self, coordinate, birth, world):
        """
        Specific constructor for OakBranch: inherits from Branch constructor

        Attributes:
            coordinate: {:class:`~treevolution.base.geometry.Point`} -- tree position on the world
            birth: {date} -- the date of birth of the tree
            wolrd: {:class:`~treevolution.world.World`} -- associated world
        """
        super().__init__(coordinate, birth, world)

        self._max_age = random.uniform(Oak.MIN_AGE, Oak.MAX_AGE)
        self._max_height = random.uniform(Oak.MIN_HEIGHT, Oak.MAX_HEIGHT)
