"""
Module for Oak branch specific representation
"""
import random

# treevolution imports
from ..branch import Branch
from ..seeds.oak import OakNut
from ..state import BranchState


class OakBranch(Branch):
    """
    Specific Oak tree branch
    """

    MIN_LENGTH, MAX_LENGTH = 1, 2.5
    MIN_LEAVES_DENSITY, MAX_LEAVES_DENSITY = 0.05, 0.1

    def __init__(self, height, angle, birth, tree):
        """
        Specific constructor for OakBranch: inherits from Branch constructor

        Attributes:
            height: {float} -- the `height` location of the branch on the tree
            angle: {float} -- the `angle` direction of the branch on the tree
            birth: {date} -- the date of birth of the branch
            tree: {:class:`~treevolution.models.tree.Tree`} -- associated tree of the branch
        """
        super().__init__(height, angle, birth, tree)

        # specific Oak branch properties
        # create random branch
        self._max_length = random.uniform(OakBranch.MIN_LENGTH, OakBranch.MAX_LENGTH)
        self._density = random.uniform(OakBranch.MIN_LEAVES_DENSITY, OakBranch.MAX_LEAVES_DENSITY)

    def width(self):
        """
        Determine the width of the branch based of its height and specie

        Returns:
            {float} -- width of the branch
        """
        return self._length * 0.05

    def evolve(self, context):
        """
        Evolve the current OakBranch instance depending of context and associated tree health

        - can increase its length
        - a new seed can appear (decreasing tree nutrient)
        - check if the branch pass in the Broken state

        Attributes:
            context: {:class:`~treevolution.context.context.Context`} -- context of the day
        """
        super().evolve(context)

        # 1. increase length only if it's possible
        if self._length < self._max_length:

            height_ratio = 1 - (self._height / self._tree.height)
            self._length += (0.005 * self._tree.youth_ratio * height_ratio)

        # 2. add seed (can decrease tree health)
        # depeding of specific criteria
        if self._tree.health > 30 and random.random() < 0.01:

            self._seeds.append(OakNut(self._tree, self, context.weather.day))

            self._tree._nutrient -= 1
            
        # 3. check if branch can fall
        wind_danger = context.weather.wind_danger(self._angle)
        
        if self._tree.health < 35 and wind_danger > 0.95 \
            and random.random() > 0.05:

            self._state = BranchState.BROKEN
