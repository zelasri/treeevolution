"""
Module which contains abstract Tree class
"""
from abc import ABC, abstractmethod
from dateutil.relativedelta import relativedelta

# treevolution imports
from .state import TreeState


class Tree(ABC):
    """
    Abstract Tree class
    """
    def __init__(self, coordinate, birth, world):
        """
        Specific constructor for OakBranch: inherits from Branch constructor

        Attributes:
            coordinate: {:class:`~treevolution.base.geometry.Point`} -- tree position on the world
            birth: {date} -- the date of birth of the tree
            wolrd: {:class:`~treevolution.world.World`} -- associated world
        """

        self._specie = type(self).__name__
        self._height = 0
        self._coordinate = coordinate
        self._branches = []
        self._nutrient = 100 # by default
        self._fallen = False
        self._birth = birth
        self._age = 0
        self._max_age = None
        self._world = world
        self._days_in_humus = None
        self._last_context = None
    
    def add_branch(self, branch):
        """
        Add branch into branch list

        Attributes:
            branch: {:class:`~treevolution.models.branch.Branch`} -- specific subclass instance of Branch
        """
        self._branches.append(branch)
        
    @property
    def nutrient(self):
        """
        Let access to the `nutrient` property of Tree
        
        Returns: 
            {float}: the tree nutrient
        """
        return self._nutrient
    
    @nutrient.setter
    def nutrient(self, nutrient):
        """
        Set the `nutrient` property of Tree
        
        Attributes:
            nutrient: {float} -- expected new height
        """
        self._nutrient = nutrient
    
    @property
    def coordinate(self):
        """
        Let access to the `coordinate` property of Tree
        
        Returns: 
            {:class:`~treevolution.base.geometry.Point`}: the tree coordinate
        """
        return self._coordinate

    @property
    def birth(self):
        """
        Let access to the `birth` property of Tree
        
        Returns: 
            {date}: the tree birthdate
        """
        return self._birth

    @property
    def age(self):
        """
        Let access to the `age` property of Tree
        
        Returns: 
            {int}: the tree age
        """
        return self._age

    @property
    def context(self):
        """
        Let access to the `context` property of Tree
        
        Returns: 
            {:class:`~treevolution.context.context.Context`}: the tree current context
        """
        return self._last_context
    
    @property
    def branches(self):
        """
        Let access to the `banches` property of Tree
        
        Returns: 
            {int}: the tree branches
        """
        return self._branches

    @property
    def world(self):
        """
        Let access to the `world` property of Tree
        
        Returns: 
            {:class:`~treevolution.world.World`}: the current associated world
        """
        return self._world

    @property
    def youth_ratio(self):
        """
        Computed youth ratio of the current tree
        
        Returns: 
            {float}: the tree youth ratio
        """
        return 1 - (self._age / self._max_age)

    @property
    def height(self):
        """
        Let access to the `height` property of Tree
        
        Returns: 
            {float}: the tree height
        """
        return self._height

    @height.setter
    def height(self, height):
        """
        Set the `height` property of Tree
        
        Attributes:
            height: {float} -- expected new height
        """
        self._height = height

    @property
    def fallen(self):
        """
        Let access to the `fallen` property of Tree
        
        Returns: 
            {bool}: the tree is fallen or not
        """
        return self._fallen

    @fallen.setter
    def fallen(self, fallen):
        """
        Set the `fallen` property of Tree
        
        Attributes:
            fallen: {bool} -- expected new fallen state
        """
        # check if humus
        if not self._fallen:
            self._days_in_humus = int(self.height **2 * self.width * len(self._branches))
      
        self._fallen = fallen


    @property
    def consumed(self):
        """
        Check if Tree in Humus state is consumed by others trees

        Returns: 
            {bool}: consumed or not
        """

        if self._fallen and self._days_in_humus <= 0:
            return True

        return False
    
    @property
    def radius(self):
        """
        Get the current radius of the tree: its largest branch

        Returns: 
            {float}: the current tree radius
        """
        max_radius = 0
        for branch in self._branches:
            if max_radius < branch.length and not branch.broken:
                max_radius = branch.length

        return max_radius

    @property
    def state(self):
        """
        Get the current Tree state

        Returns: 
            {:enum:`~treevolution.models.state.TreeState`}: the current tree state value
        """
        if self.fallen:
            return TreeState.HUMUS

        if self._age >= self._max_age and not self._fallen:
            self.fallen = True
            return TreeState.HUMUS

        return TreeState.TREE

    @property
    @abstractmethod
    def health(self):
        """
        Compute the current health of the OakTree
        Available branches can affect the OakTree health

        Returns: 
            {float}: the current tree health
        """

    @property
    @abstractmethod
    def width(self):
        """
        Determine the width of the trunk tree based of its height and specie

        Returns:
            {float} -- the trunk width of tree
        """

    @abstractmethod
    def evolve(self, context):
        """
        Simulate tree behavior with current day context

        Attributes:
            context: {:class:`~treevolution.context.context.Context`} -- context of the day
        """
        self._last_context = context
        
        self._age = relativedelta(context.weather.day, self._birth).years

        if self._days_in_humus is not None and self._days_in_humus > 0:
            self._days_in_humus -= 1

        # if state is HUMUS due to end of life
        if self.state == TreeState.HUMUS:
            return

        # default behavior
        for branch in self._branches:
            if not branch.broken:
                branch.evolve(context)
        

    def __str__(self):
        """
        `str` representation Point information

        Returns: 
            {str}: expected formated data
        """
        return f"(name: {self._specie}, height: {self._height:.2f}, width: {self.width:.2f}, "\
                f"coordinate: {self._coordinate}, health: {self.health:.2f}, "\
                f"nutrient: {self._nutrient:.2f}, age: {self._age}, radius: {self.radius:.2f}, "\
                f"branches: {len(self._branches)}, state: {self.state}, "\
                f"humus_days: {self._days_in_humus})"

    def to_json(self):
        """
        Convert current instance of tree into json data
        
        Returns: 
            {json}: the json representation of the tree
        """
        
        broken_branches = len([ b for b in self._branches if b.broken ])

        return {
            "specie": self._specie,
            "birth": str(self._birth),
            "coordinate": self._coordinate.to_json(),
            "height": self._height,
            "width": self.width,
            "radius": self.radius,
            "health": self.health,
            "nutrient": self._nutrient,
            "age": self.age,
            "max_age": self._max_age,
            "youth_ratio": self.youth_ratio,
            "state": str(self.state),
            "fallen": self._fallen,
            "days_in_humus": str(self._days_in_humus),
            "consumed": self.consumed,
            "branches": [b.to_json() for b in self._branches],
            "broken_branches": broken_branches
        }
