"""
Module which contains abstract Branch class
"""
from abc import ABC, abstractmethod

# treevolution imports
from ..base.geometry import Point
from ..base.physics import fallen_body_coordinate
from .state import BranchState

class Branch(ABC):
    """
    Representation of the tree branch attached to a Trunk
    - height on the tree trunk
    - length of the branch (can evolve)
    - angle which caracterizes the position
    - density of leaves (enable to get amount of light intensity that can pass)
    """

    def __init__(self, height, angle, birth, tree):
        """
        Abstract constructor for Branch

        Attributes:
            height: {float} -- the `height` location of the branch on the tree
            angle: {float} -- the `angle` direction of the branch on the tree
            birth: {date} -- the date of birth of the branch
            tree: {:class:`~treevolution.models.tree.Tree`} -- associated tree of the branch
        """
        self._tree = tree
        self._birth = birth
        self._angle = angle
        self._height = height
        self._state = BranchState.EVOLVE
        self._seeds = []
        self._length = 0
        self._density = 0

    @property
    def broken(self):
        """
        Let access to the current branch state

        Returns:
            {int} -- the branch state
        """
        return self._state == BranchState.BROKEN

    @property
    def length(self):
        """
        Let access to the current branch length

        Returns:
            {float} -- the branch length
        """
        return self._length

    @property
    def birth(self):
        """
        Let access to the current branch birth

        Returns:
            {date} -- the branch birth
        """
        return self._birth

    @property
    def density(self):
        """
        Let access to the current branch leaves density

        Returns:
            {float} -- the branch leaves density
        """
        return self._density

    @property
    def height(self):
        """
        Let access to the current branch heigth

        Returns:
            {float} -- the branch heigth
        """
        return self._height
    
    @property
    def seeds(self):
        """
        Let access to the current seeds of branch

        Returns:
            [{:class:`~treevolution.models.seed.Seed`}] -- the branch seeds
        """
        return self._seeds

    @height.setter
    def height(self, height):
        """
        height setter for branch

        Attributes:
            height: {float} -- new associated heigth
        """
        self._height = height

    @property
    def angle(self):
        """
        Let access to the current branch direction

        Returns:
            {float} -- the branch angle
        """
        return self._angle

    @abstractmethod
    def evolve(self, context):
        """
        Simulate branch behavior due to current day context
        - Seed can dropped into the current world map
        - Need to define evolution rules
        
        Attributes:
            context: {:class:`~treevolution.context.context.Context`} -- context of the day
        """

        # seed evolution is required
        for seed in self._seeds:
            
            seed.evolve(context.weather)

            # add it into world (with specific weather position)
            # remove it from branch
            if seed.fallen:

                # find the traveled distance after the fall
                seed.coordinate = fallen_body_coordinate(context.weather, self._height, seed.coordinate)
                
                # check if seed is inside the world
                # create border points
                point_1 = Point(0, 0)
                point_2 = Point(self._tree.world.width, self._tree.world.height)

                # only if inside we add it to the world
                if seed.coordinate.is_inside_rectangle(point_1, point_2):
                    self._tree.world.add_seed(seed)

                self._seeds.remove(seed)

            # by default seed is dead and is removed
            # due to the fact that maturity wasn't reached
            if self.broken:
                
                self._seeds.remove(seed)

    def __str__(self):
        """
        `str` representation Point information

        Returns: 
            {str}: expected formated data
        """
        return f"(height: {self._height:.2f}, length: {self._length:.2f}, "\
                f"angle: {self._angle:.2f}, density: {self._density:.2f}, "\
                f"seeds: {len(self._seeds)}, broken: {self.broken}, "\
                f"birth: {self.birth})"

    def to_json(self):
        """
        Convert current instance of branch into json data
        
        Returns: 
            {json}: the json representation of the branch
        """

        return {
            "birth": str(self._birth),
            "height": self._height,
            "length": self._length,
            "angle": self._angle,
            "density": self._density,
            "state": str(self._state),
            "broken": self.broken,
            "seeds": [s.to_json() for s in self._seeds]
        }
