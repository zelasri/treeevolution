"""
Module for abstract seed representation
"""
from abc import ABC, abstractmethod

# treevolution imports
from .state import SeedState

class Seed(ABC):
    """
    Abstrast Seed class
    """

    def __init__(self, tree, branch, birth):
        """
        Abstract constructor for Seed

        Attributes:
            tree: {:class:`~treevolution.models.tree.Tree`} -- associated tree of the seed
            branch: {:class:`~treevolution.models.branch.ranch`} -- associated branch of the seed
            birth: {date} -- the date of birth of the seed
        """

        self._tree = tree
        self._coordinate = tree.coordinate
        self._branch = branch
        self._birth = birth
        self._fallen = False
        self._days_before_maturity = None
        self._days_before_dead = None
        self._fallen_day = None
        self._state = SeedState.ON_BRANCH

    @property
    def birth(self):
        """
        Let access to the `date` property of Seed
        
        Returns: 
            {date}: the `date` Seed property
        """
        return self._birth

    @property
    def tree_type(self):
        """
        Specify the tree type associated to the seed
        
        Returns: 
            {type}: the tree type class of seed
        """
        return type(self._tree)
    
    @property
    def state(self):
        """
        Let access to the `state` property of Point
        
        Returns: 
            {int}: the `state` Seed property
        """
        return self._state

    @property
    def fallen_day(self):
        """
        Let access to the `fallen_day` property of Point
        
        Returns: 
            {date}: the `fallen_day` Seed property
        """
        return self._fallen_day

    @property
    def fallen(self):
        """
        Tells if seed is fallen or not
        
        Returns: 
            {date}: the `fallen` Seed property
        """
        return self._fallen

    @property
    def coordinate(self):
        """
        Current coordinate of the seed on the world map

        Returns:
            {:class:`~treevolution.base.geometry.Point`}: random instance
        """
        return self._coordinate

    @coordinate.setter
    def coordinate(self, coordinate):
        """
        Set the current coordinate of seed on the map

        Attributes:
            coordinate: {:class:`~treevolution.base.geometry.Point`} -- specific coordinate
        """
        self._coordinate = coordinate

    @abstractmethod
    def evolve(self, weather):
        """
        Evolve the current Seed instance depending of the weather only

        Attributes:
            weather: {:class:`~treevolution.context.weather.Weather`} -- weather of the day
        """
        n_days = (weather.day - self._birth).days
            
        # check if seed reached its maturity
        if not self._fallen:
                
            if n_days >= self._days_before_maturity:
                self._fallen = True
                self._state = SeedState.WAITING

        # check dead case
        if SeedState.WAITING:
                
            if n_days >= (self._days_before_dead + self._days_before_maturity):
                self._state = SeedState.DEAD
        
    def to_json(self):
        """
        Convert current instance of seed into json data
        
        Returns: 
            {json}: the json representation of the seed
        """

        return {
            "birth": str(self._birth),
            "coordinate": self._coordinate.to_json(),
            "tree_type": self.tree_type.__name__,
            "state": str(self._state),
            "fallen": self._fallen,
            "fallen_day": str(self._fallen_day),
            "days_before_maturity": self._days_before_maturity,
            "days_before_dead": self._days_before_dead
        }
