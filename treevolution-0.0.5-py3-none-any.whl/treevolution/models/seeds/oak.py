"""
Module for Oak Seed specific representation
"""
import random

# treevolution imports
from ..seed import Seed
from ..state import SeedState

class OakNut(Seed):
    """
    Specific Oak seed
    """

    MIN_MATURITY, MAX_MATURITY = 30, 40
    MIN_SURVIVE, MAX_SURVIVE = 20, 25

    def __init__(self, tree, branch, birth):
        """
        Specific constructor for OakNut: inherits from Seed constructor

        Attributes:
            tree: {:class:`~treevolution.models.tree.Tree`} -- associated tree of the seed
            branch: {:class:`~treevolution.models.branch.ranch`} -- associated branch of the seed
            birth: {date} -- the date of birth of the seed
        """
        super().__init__(tree, branch, birth)

        self._days_before_maturity = random.randint(OakNut.MIN_MATURITY, OakNut.MAX_MATURITY)
        self._days_before_dead = random.randint(OakNut.MIN_SURVIVE, OakNut.MAX_SURVIVE)

    def evolve(self, weather):
        """
        Evolve the current OakNut instance depending of the weather only

        Attributes:
            weather: {:class:`~treevolution.context.weather.Weather`} -- weather of the day
        """
        super().evolve(weather)

        # WAITING state is required
        if self._state == SeedState.WAITING:

            # 1. check if seed is eaten
            if random.random() > 0.8:
                self._state = SeedState.EATEN

            # 3. check probability to evolve as tree
            elif random.random() > 0.98:
                self._state = SeedState.TREE
