"""Util module with physics function
"""
import math

from . import Point

def fallen_body_coordinate(weather, height, coordinate):
    """Compute the new coordinate of a fallen body

    Args:
        weather: {:class:`~treevolution.base.context.weather.Weather`} -- current weather
        height: {float} -- initial height (altitude) of object in meter
        coordinate: {:class:`~treevolution.base.geometry.Point`} -- coordinate of object

    Returns:
        {:class:`~treevolution.base.geometry.Point`}: computed coordinate
    """
    # convert km/h into m/s
    speed_ms = weather.wind_speed * 1000 / 3600
    
    # use free fall equation : https://en.wikipedia.org/wiki/Free_fall
    # computed elapsed time (4.9 for: 1/2 * g)
    # g the well known gravitational constant
    elapsed_time = math.sqrt(height / (4.9))
    distance = speed_ms * elapsed_time
        
    # computed new coordinate
    # convert compass angle to trigonometric circle
    add_x = math.cos((-weather.wind_angle + 90) \
                        * (math.pi / 180)) * distance
    add_y = math.sin((-weather.wind_angle + 90) \
                        * (math.pi / 180)) * distance
    
    return Point(coordinate.x + add_x, coordinate.y + add_y)
